The bot at the first stage will be answer simple questions. As the database grows, which will be fill in the postgres bd.
Base:
System - Ubuntu20.04lts
Programming environment - Python3.8.2
Programming environment - Python3.9.5
Python dependencies from requirements.txt
Install:
Command for install Python:
sudo apt install python3.8
sudo apt install python3.9
Command for install pip:
sudo apt install python3-pip
Check version Python:
Python3 --version
Check version pip:
pip3 --version
Others.
Install:
pip3 install PyTelegramBotAPI
pip3 install sklearn
pip3 install wikipedia
Check install python-libs:
command python3.8
command python3.9
import re # base python-lib
import sklearn
import telebot
import wikipedia
