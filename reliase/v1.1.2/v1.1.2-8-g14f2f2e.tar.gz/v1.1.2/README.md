The bot will be token in file, comfig.py.
Base:
System - Ubuntu20.04lts
Programming environment - Python3.8.2
Programming environment - Python3.9.5
Python dependencies from requirements.txt
Install:
Command for install Python:
sudo apt install python3.8
sudo apt install python3.9
Command for install pip:
sudo apt install python3-pip
Check version Python:
Python3 --version
Check version pip:
pip3 --version
Others.
Install:
Base:
pip3 install aiogram
pip3 install aiogram-utils
Upgrade:
pip3 install --upgrade aiogram
pip3 install --upgrade aiohttp
pip3 install --upgrade aiosignal
pip3 install --upgrade async-timeout
pip3 install --upgrade attrs
pip3 install --upgrade Babel
pip3 install --upgrade certifi
pip3 install --upgrade dnspython
pip3 install --upgrade frozenlist
pip3 install --upgrade magic-filter
pip3 install --upgrade mongoengine
pip3 install --upgrade multidict
pip3 install --upgrade pymongo
pip3 install --upgrade pytz
pip3 install --upgrade yarl
Check install python-libs:
command python3.8
command python3.9
import aiogram
import aiogram.dispatcher # class Dispatcher from message
import aiogram.utils
import config # token
Reliase:
version==1.1.0
version==1.1.1
version==1.1.2
